// Firebase configuration, initialisation and helper functions
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyDXunTOlIaOjlnjAbBZ6MGQfbQR1eI4qWQ",
  authDomain: "skillbridge-app-78a40.firebaseapp.com",
  projectId: "skillbridge-app-78a40",
  storageBucket: "skillbridge-app-78a40.firebasestorage.app",
  messagingSenderId: "1035863326656",
  appId: "1:1035863326656:web:02aa01947539ae40a59225",
  measurementId: "G-KM3Q6MFRTK"
};

// ─── Initialize Firebase ───────────────────────────────────────────────────────
const firebaseApp = firebase.initializeApp(FIREBASE_CONFIG);
const db = firebase.firestore();
const auth = firebase.auth();

// ─── Firebase helpers ──────────────────────────────────────────────────────────
const FB = {
  // Auth
  async register(email, password, name, role) {
    const cred = await auth.createUserWithEmailAndPassword(email, password);
    const user = { id: cred.user.uid, name, email, role, color: '#1a56db', createdAt: new Date().toISOString() };
    await db.collection('users').doc(cred.user.uid).set(user);
    return user;
  },
  async login(email, password) {
    const cred = await auth.signInWithEmailAndPassword(email, password);
    const snap = await db.collection('users').doc(cred.user.uid).get();
    return snap.exists ? { id: cred.user.uid, ...snap.data() } : { id: cred.user.uid, email };
  },
  async logout() { await auth.signOut(); },

  // Freelancers
  async getFreelancers() {
    const snap = await db.collection('freelancers').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async saveFreelancer(data) {
    await db.collection('freelancers').doc(data.id).set(data, { merge: true });
  },

  // Jobs
  async getJobs() {
    const snap = await db.collection('jobs').orderBy('createdAt', 'desc').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async postJob(job) {
    const ref = await db.collection('jobs').add({ ...job, createdAt: new Date().toISOString() });
    return { id: ref.id, ...job };
  },

  // Messages — real-time listener
  listenMessages(chatKey, callback) {
    return db.collection('messages').doc(chatKey).collection('msgs')
      .orderBy('time').onSnapshot(snap => {
        callback(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      });
  },
  async sendMessage(chatKey, msg) {
    await db.collection('messages').doc(chatKey).collection('msgs').add(msg);
  },

  // Reviews
  async getReviews(freelancerId) {
    const snap = await db.collection('reviews').doc(freelancerId).collection('items').get();
    return snap.docs.map(d => ({ id: d.id, ...d.data() }));
  },
  async addReview(freelancerId, review) {
    await db.collection('reviews').doc(freelancerId).collection('items').add(review);
  },
};
