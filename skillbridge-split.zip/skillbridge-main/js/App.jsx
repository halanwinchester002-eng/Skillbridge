function App() {
  const [page, setPage] = useState('home');
  const [currentUser, setCurrentUser] = useState(null);
  const [authModal, setAuthModal] = useState(null);
  const [toasts, setToasts] = useState([]);

  // Sync Firebase auth state & load real data on startup
  useEffect(() => {
    const unsub = auth.onAuthStateChanged(async fbUser => {
      if (fbUser) {
        const snap = await db.collection('users').doc(fbUser.uid).get();
        if (snap.exists) setCurrentUser({ id: fbUser.uid, ...snap.data() });
      } else {
        setCurrentUser(null);
      }
    });
    // Load freelancers and jobs from Firestore into STORE
    FB.getFreelancers().then(list => { if (list.length > 0) STORE.freelancers = list; }).catch(() => {});
    FB.getJobs().then(list => { if (list.length > 0) STORE.jobs = list; }).catch(() => {});
    return () => unsub();
  }, []);

  function showToast(msg, type = 'success') {
    const id = newId();
    setToasts(t => [...t, { id, msg, type }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3500);
  }

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'freelancers', label: 'Find Freelancers' },
    { id: 'jobs', label: 'Jobs' },
    { id: 'messages', label: 'Messages' },
    { id: 'profile', label: 'My Profile' },
  ];

  return (
    <AppCtx.Provider value={{ showToast }}>
      <ToastContainer toasts={toasts} />
      <nav className="nav">
        <div className="nav-inner">
          <div className="nav-logo" onClick={() => setPage('home')} style={{ cursor: 'pointer' }}>
            HALAN<span>GERALD A</span>
          </div>
          <div className="nav-links">
            {navItems.slice(0,3).map(item => (
              <button key={item.id} className={`nav-link ${page === item.id ? 'active' : ''}`} onClick={() => setPage(item.id)}>
                {item.label}
              </button>
            ))}
          </div>
          <div className="nav-actions">
            {currentUser ? (
              <>
                <button className={`nav-link ${page === 'messages' ? 'active' : ''}`} onClick={() => setPage('messages')}>💬 Messages</button>
                <button className="btn btn-secondary btn-sm" onClick={() => setPage('profile')}>
                  <Avatar name={currentUser.name} color={currentUser.color || '#1a56db'} size="sm" />
                  {currentUser.name.split(' ')[0]}
                </button>
                <button className="btn btn-ghost btn-sm" onClick={() => { FB.logout(); setCurrentUser(null); showToast('Signed out', 'success'); setPage('home'); }}>Sign Out</button>
              </>
            ) : (
              <>
                <button className="btn btn-ghost btn-sm" onClick={() => setAuthModal('login')}>Sign In</button>
                <button className="btn btn-primary btn-sm" onClick={() => setAuthModal('register')}>Get Started</button>
              </>
            )}
          </div>
        </div>
      </nav>

      {page === 'home' && <HomePage setPage={setPage} />}
      {page === 'freelancers' && <FreelancersPage currentUser={currentUser} setPage={setPage} />}
      {page === 'jobs' && <JobsPage currentUser={currentUser} showToast={showToast} />}
      {page === 'messages' && <MessagesPage currentUser={currentUser} />}
      {page === 'profile' && <ProfilePage currentUser={currentUser} setCurrentUser={setCurrentUser} showToast={showToast} />}
      {page === 'register' && <AuthModal mode="register" onClose={() => setPage('home')} onAuth={u => { setCurrentUser(u); setPage('profile'); showToast('Welcome to HALAN GERALD A!', 'success'); }} />}

      {authModal && (
        <AuthModal mode={authModal} onClose={() => setAuthModal(null)} onAuth={u => { setCurrentUser(u); showToast(`Welcome back, ${u.name.split(' ')[0]}!`, 'success'); }} />
      )}

      <footer style={{ background: 'var(--surface)', borderTop: '1px solid var(--border)', padding: '40px 24px', marginTop: 60 }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', gap: 40, flexWrap: 'wrap' }}>
          <div>
            <div className="nav-logo" style={{ fontSize: 22, marginBottom: 10 }}>HALAN<span style={{ color: 'var(--text-primary)' }}>GERALD A</span></div>
            <p style={{ fontSize: 14, color: 'var(--text-secondary)', maxWidth: 260 }}>The professional freelance marketplace connecting talent with opportunity.</p>
          </div>
          {[['For Clients',['Post a Job','Browse Freelancers','How it Works']],['For Freelancers',['Create Profile','Find Work','Portfolio Tips']],['Company',['About Us','Blog','Contact']]].map(([title, links]) => (
            <div key={title}>
              <h4 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-muted)', marginBottom: 12 }}>{title}</h4>
              {links.map(l => <div key={l} style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 8, cursor: 'pointer' }}>{l}</div>)}
            </div>
          ))}
        </div>
        <div style={{ maxWidth: 1200, margin: '28px auto 0', borderTop: '1px solid var(--border)', paddingTop: 20, fontSize: 13, color: 'var(--text-muted)', textAlign: 'center' }}>
          <div>© 2025 <strong style={{ color: 'var(--text-secondary)' }}>HALAN GERALD A</strong>. All rights reserved.</div>
          <div style={{ marginTop: 6, fontSize: 12 }}>
            This platform is an original work owned by HALAN GERALD A. Unauthorized copying, reproduction, or redistribution of this platform, in whole or in part, is strictly prohibited.
          </div>
          <div style={{ marginTop: 6, fontSize: 12 }}>
            Built with React + Firebase · Deployed on Netlify · Made in India 🇮🇳
          </div>
        </div>
      </footer>
    </AppCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
