function AuthModal({ mode, onClose, onAuth }) {
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'client' });
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!form.email || !form.password || (mode === 'register' && !form.name)) return;
    setLoading(true);
    try {
      let user;
      if (mode === 'register') {
        user = await FB.register(form.email, form.password, form.name, form.role);
      } else {
        user = await FB.login(form.email, form.password);
      }
      onAuth(user);
      onClose();
    } catch (err) {
      alert(err.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Modal onClose={onClose} title={mode === 'login' ? 'Sign In' : 'Create Account'}
      footer={
        <>
          <button className="btn btn-secondary" onClick={onClose}>Cancel</button>
          <button className="btn btn-primary" onClick={submit} disabled={loading}>
            {loading ? <div className="spinner" style={{ width: 16, height: 16 }} /> : (mode === 'login' ? 'Sign In' : 'Create Account')}
          </button>
        </>
      }>
      {mode === 'register' && (
        <div className="form-group">
          <label className="form-label">Full Name</label>
          <input className="form-input" value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))} placeholder="Your full name" />
        </div>
      )}
      <div className="form-group">
        <label className="form-label">Email</label>
        <input className="form-input" type="email" value={form.email} onChange={e => setForm(p => ({ ...p, email: e.target.value }))} placeholder="you@example.com" />
      </div>
      <div className="form-group">
        <label className="form-label">Password</label>
        <input className="form-input" type="password" value={form.password} onChange={e => setForm(p => ({ ...p, password: e.target.value }))} placeholder="••••••••" />
      </div>
      {mode === 'register' && (
        <div className="form-group">
          <label className="form-label">I am a…</label>
          <div style={{ display: 'flex', gap: 10 }}>
            {['client','freelancer'].map(r => (
              <button key={r} className="btn" style={{ flex: 1, justifyContent: 'center', background: form.role === r ? 'var(--brand-light)' : 'var(--surface)', border: `1px solid ${form.role === r ? 'var(--brand)' : 'var(--border-strong)'}`, color: form.role === r ? 'var(--brand)' : 'var(--text-secondary)', textTransform: 'capitalize' }} onClick={() => setForm(p => ({ ...p, role: r }))}>
                {r === 'client' ? '🏢 ' : '👤 '}{r}
              </button>
            ))}
          </div>
        </div>
      )}
    </Modal>
  );
}
