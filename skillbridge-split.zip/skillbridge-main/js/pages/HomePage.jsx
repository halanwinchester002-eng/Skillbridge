function HomePage({ setPage }) {
  return (
    <div className="fade-in">
      <div className="hero">
        <div style={{ maxWidth: 700, margin: '0 auto' }}>
          <h1>Find <em>skilled professionals</em> for every project</h1>
          <p>Connect with top freelancers in engineering, design, photography, writing, and more. Post a job or create your profile today.</p>
          <div className="hero-btns">
            <button className="btn btn-primary" style={{ background: '#fff', color: '#1a56db' }} onClick={() => setPage('freelancers')}>
              Browse Freelancers
            </button>
            <button className="btn btn-secondary" style={{ borderColor: 'rgba(255,255,255,0.4)', color: '#fff', background: 'rgba(255,255,255,0.1)' }} onClick={() => setPage('jobs')}>
              Post a Job
            </button>
          </div>
        </div>
      </div>

      <div className="stats-bar">
        <div className="stats-bar-inner">
          {[['2,400+','Skilled freelancers'],['890+','Companies hiring'],['14,200+','Projects completed'],['4.8★','Average rating']].map(([n,l]) => (
            <div className="stat-item" key={l}>
              <span className="stat-num">{n}</span>
              <span className="stat-label">{l}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="section">
        <h2 style={{ fontSize: 24, fontWeight: 600, marginBottom: 24 }}>Browse by category</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))', gap: 14 }}>
          {[['⚙️','Engineering'],['🎨','Design'],['📸','Photography'],['✍️','Writing'],['📊','Data & Analytics'],['📱','Mobile Dev'],['🎬','Video Editing'],['🔊','Marketing']].map(([icon, cat]) => (
            <button key={cat} className="card card-hover" style={{ padding: '20px 16px', textAlign: 'center', border: 'none', width: '100%', cursor: 'pointer', background: 'white' }}
              onClick={() => setPage('freelancers')}>
              <div style={{ fontSize: 28, marginBottom: 8 }}>{icon}</div>
              <div style={{ fontSize: 14, fontWeight: 500 }}>{cat}</div>
            </button>
          ))}
        </div>
      </div>

      <div className="section" style={{ paddingTop: 0 }}>
        <h2 style={{ fontSize: 24, fontWeight: 600, marginBottom: 24 }}>Latest job postings</h2>
        <div className="grid-2">
          {STORE.jobs.slice(0,4).map(job => (
            <div key={job.id} className="card card-hover">
              <div className="job-card">
                <div className="job-card-header">
                  <div>
                    <div className="job-card-title">{job.title}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>{job.clientName}</div>
                  </div>
                  <span className="badge badge-blue">{job.category}</span>
                </div>
                <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{job.description.slice(0, 100)}…</p>
                <div className="job-card-meta">
                  <span>💰 {job.budget}</span>
                  <span>⏱ {job.duration}</span>
                  <span>👤 {job.proposals} proposals</span>
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {job.skills.map(s => <span className="chip" key={s}>{s}</span>)}
                </div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ textAlign: 'center', marginTop: 28 }}>
          <button className="btn btn-secondary" onClick={() => setPage('jobs')}>View all jobs →</button>
        </div>
      </div>

      <div style={{ background: 'var(--brand)', color: '#fff', padding: '60px 24px', textAlign: 'center' }}>
        <h2 style={{ fontFamily: "'DM Serif Display',serif", fontSize: 32, marginBottom: 12 }}>Are you a freelancer?</h2>
        <p style={{ opacity: 0.85, marginBottom: 28, fontSize: 16 }}>Create your profile, showcase your skills, and start getting hired today.</p>
        <button className="btn" style={{ background: '#fff', color: 'var(--brand)', padding: '12px 28px', fontSize: 15 }} onClick={() => setPage('register')}>
          Create Free Profile
        </button>
      </div>
    </div>
  );
}
