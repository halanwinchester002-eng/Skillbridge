function FreelancersPage({ currentUser, setPage }) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [selected, setSelected] = useState(null);
  const [showContact, setShowContact] = useState(false);
  const [message, setMessage] = useState('');
  const { showToast } = React.useContext(AppCtx);

  const categories = ['All', 'Engineering', 'Design', 'Photography', 'Writing'];
  const filtered = STORE.freelancers.filter(f => {
    const matchCat = category === 'All' || f.category === category;
    const matchSearch = !search || f.name.toLowerCase().includes(search.toLowerCase()) ||
      f.skills.some(s => s.toLowerCase().includes(search.toLowerCase())) ||
      f.title.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  function sendMessage() {
    if (!message.trim()) return;
    const key = `${currentUser?.id || 'guest'}_${selected.id}`;
    if (!STORE.messages[key]) STORE.messages[key] = [];
    STORE.messages[key].push({ id: newId(), from: currentUser?.id || 'guest', text: message, time: new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) });
    setShowContact(false);
    setMessage('');
    showToast('Message sent!', 'success');
    setPage('messages');
  }

  return (
    <div className="fade-in">
      <div style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <h1 style={{ fontSize: 28, fontWeight: 600, marginBottom: 20 }}>Browse Freelancers</h1>
          <div className="search-wrap" style={{ maxWidth: 600 }}>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by name, skill, or title…" />
            <select value={category} onChange={e => setCategory(e.target.value)}>
              {categories.map(c => <option key={c}>{c}</option>)}
            </select>
            <button>Search</button>
          </div>
        </div>
      </div>

      <div className="section">
        <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
          {categories.map(c => (
            <button key={c} className={`badge ${category === c ? 'badge-blue' : 'badge-gray'}`} style={{ cursor: 'pointer', padding: '6px 16px', fontSize: 13 }} onClick={() => setCategory(c)}>{c}</button>
          ))}
          <span style={{ fontSize: 14, color: 'var(--text-muted)', marginLeft: 'auto', alignSelf: 'center' }}>{filtered.length} freelancers found</span>
        </div>

        {filtered.length === 0 ? (
          <div className="empty">
            <div className="empty-icon">🔍</div>
            <h3>No freelancers found</h3>
            <p>Try adjusting your search or category filter.</p>
          </div>
        ) : (
          <div className="grid-3">
            {filtered.map(f => (
              <div key={f.id} className="card card-hover" style={{ cursor: 'pointer' }} onClick={() => setSelected(f)}>
                <div className="profile-card">
                  <div className="profile-card-top">
                    <Avatar name={f.name} color={f.color} size="lg" />
                    <div className="profile-card-info">
                      <h3>{f.name}</h3>
                      <p>{f.title}</p>
                      <p style={{ marginTop: 4 }}>📍 {f.location}</p>
                    </div>
                    <span className={`badge ${f.available ? 'badge-green' : 'badge-gray'}`} style={{ marginLeft: 'auto', flexShrink: 0 }}>
                      {f.available ? 'Available' : 'Busy'}
                    </span>
                  </div>
                  <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{f.bio.slice(0, 90)}…</p>
                  <div className="profile-card-skills">
                    {f.skills.slice(0, 3).map(s => <span className="chip" key={s}>{s}</span>)}
                  </div>
                  <div className="profile-card-footer">
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <span className="stars">{'★'.repeat(Math.round(f.rating))}</span>
                      <span style={{ fontSize: 13, fontWeight: 600 }}>{f.rating}</span>
                      <span style={{ fontSize: 12, color: 'var(--text-muted)' }}>({f.reviews})</span>
                    </div>
                    <span style={{ fontSize: 14, fontWeight: 600, color: 'var(--brand)' }}>{f.rate}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Freelancer Detail Modal */}
      {selected && (
        <Modal onClose={() => setSelected(null)} title="Freelancer Profile"
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setSelected(null)}>Close</button>
              <button className="btn btn-primary" onClick={() => { setShowContact(true); setSelected(null); }}>Contact {selected.name.split(' ')[0]}</button>
            </>
          }>
          <div style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
            <Avatar name={selected.name} color={selected.color} size="xl" />
            <div style={{ flex: 1 }}>
              <h2 style={{ fontSize: 20, fontWeight: 600 }}>{selected.name}</h2>
              <p style={{ color: 'var(--text-secondary)', marginTop: 4 }}>{selected.title} · {selected.location}</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
                <StarRating value={Math.round(selected.rating)} readonly />
                <span style={{ fontSize: 14 }}>{selected.rating} ({selected.reviews} reviews)</span>
              </div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 18, fontWeight: 700, color: 'var(--brand)' }}>{selected.rate}</div>
              <span className={`badge ${selected.available ? 'badge-green' : 'badge-gray'}`}>{selected.available ? 'Available now' : 'Currently busy'}</span>
            </div>
          </div>

          <div>
            <h4 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-muted)', marginBottom: 8 }}>About</h4>
            <p style={{ fontSize: 14, lineHeight: 1.7 }}>{selected.bio}</p>
          </div>

          <div>
            <h4 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-muted)', marginBottom: 10 }}>Skills</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {selected.skills.map(s => <span className="chip" key={s}>{s}</span>)}
            </div>
          </div>

          {selected.portfolio?.length > 0 && (
            <div>
              <h4 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-muted)', marginBottom: 10 }}>Portfolio</h4>
              <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
                {selected.portfolio.map(p => (
                  <div key={p} style={{ background: 'var(--surface-hover)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '10px 16px', fontSize: 13, fontWeight: 500 }}>
                    📁 {p}
                  </div>
                ))}
              </div>
            </div>
          )}

          {(STORE.reviews[selected.id] || []).length > 0 && (
            <div>
              <h4 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', letterSpacing: 0.5, color: 'var(--text-muted)', marginBottom: 10 }}>Reviews</h4>
              {STORE.reviews[selected.id].map(r => (
                <div key={r.id} style={{ background: 'var(--surface-alt)', borderRadius: 'var(--radius-sm)', padding: '12px 14px', marginBottom: 8 }}>
                  <div style={{ display: 'flex', justify: 'space-between', gap: 8 }}>
                    <strong style={{ fontSize: 14 }}>{r.clientName}</strong>
                    <StarRating value={r.rating} readonly />
                    <span style={{ fontSize: 12, color: 'var(--text-muted)', marginLeft: 'auto' }}>{r.date}</span>
                  </div>
                  <p style={{ fontSize: 14, marginTop: 6, color: 'var(--text-secondary)' }}>{r.text}</p>
                </div>
              ))}
            </div>
          )}
        </Modal>
      )}

      {/* Contact Modal */}
      {showContact && selected && (
        <Modal onClose={() => setShowContact(false)} title={`Message ${selected.name}`}
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setShowContact(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={sendMessage}>Send Message</button>
            </>
          }>
          <p style={{ fontSize: 14, color: 'var(--text-secondary)' }}>Introduce yourself and describe what you're looking for.</p>
          <div className="form-group">
            <label className="form-label">Your message</label>
            <textarea className="form-input" rows={5} value={message} onChange={e => setMessage(e.target.value)} placeholder={`Hi ${selected.name.split(' ')[0]}, I came across your profile and I'm interested in...`} />
          </div>
        </Modal>
      )}
    </div>
  );
}
