function MessagesPage({ currentUser }) {
  const [activeChat, setActiveChat] = useState(null);
  const [input, setInput] = useState('');
  const [liveMessages, setLiveMessages] = useState([]);
  const [, forceUpdate] = useState(0);
  const bottomRef = useRef(null);
  const unsubRef = useRef(null);

  const freeName = id => STORE.freelancers.find(f => f.id === id)?.name || 'Unknown';
  const freeColor = id => STORE.freelancers.find(f => f.id === id)?.color || '#1a56db';

  const chatKeys = Object.keys(STORE.messages);
  const myChats = chatKeys.filter(k => k.startsWith((currentUser?.id || 'guest') + '_'));

  useEffect(() => {
    if (!activeChat) return;
    const key = `${currentUser?.id || 'guest'}_${activeChat}`;
    if (unsubRef.current) unsubRef.current();
    unsubRef.current = FB.listenMessages(key, msgs => {
      setLiveMessages(msgs);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    });
    return () => { if (unsubRef.current) unsubRef.current(); };
  }, [activeChat]);

  async function sendMsg() {
    if (!input.trim() || !activeChat) return;
    const key = `${currentUser?.id || 'guest'}_${activeChat}`;
    const msg = { from: currentUser?.id || 'guest', text: input, time: new Date().toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}) };
    // Keep local STORE in sync for chat list preview
    if (!STORE.messages[key]) STORE.messages[key] = [];
    STORE.messages[key].push({ id: newId(), ...msg });
    setInput('');
    forceUpdate(n => n+1);
    try { await FB.sendMessage(key, msg); } catch(e) {}
  }

  const msgs = liveMessages.length > 0 ? liveMessages : (activeChat ? (STORE.messages[`${currentUser?.id || 'guest'}_${activeChat}`] || []) : []);

  return (
    <div className="fade-in">
      <div style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '20px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <h1 style={{ fontSize: 24, fontWeight: 600 }}>Messages</h1>
        </div>
      </div>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '24px' }}>
        <div className="card" style={{ display: 'flex', height: 520 }}>
          <div className="chat-list">
            <div style={{ padding: '14px 18px', fontWeight: 600, fontSize: 14, borderBottom: '1px solid var(--border)', color: 'var(--text-muted)' }}>CONVERSATIONS</div>
            {myChats.length === 0 ? (
              <div style={{ padding: '32px 18px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 14 }}>
                No conversations yet.<br/>Browse freelancers to start chatting.
              </div>
            ) : myChats.map(key => {
              const fid = key.split('_')[1];
              const lastMsg = STORE.messages[key]?.slice(-1)[0];
              return (
                <div key={key} className={`chat-item ${activeChat === fid ? 'active' : ''}`} onClick={() => setActiveChat(fid)}>
                  <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                    <Avatar name={freeName(fid)} color={freeColor(fid)} />
                    <div style={{ flex: 1, minWidth: 0 }}>
                      <div style={{ fontSize: 14, fontWeight: 500 }}>{freeName(fid)}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{lastMsg?.text}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            {!activeChat ? (
              <div className="empty" style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
                <div className="empty-icon">💬</div>
                <h3>Select a conversation</h3>
                <p>Choose a conversation or start a new one from the Freelancers page.</p>
              </div>
            ) : (
              <>
                <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--border)', display: 'flex', gap: 12, alignItems: 'center' }}>
                  <Avatar name={freeName(activeChat)} color={freeColor(activeChat)} />
                  <div><div style={{ fontWeight: 600 }}>{freeName(activeChat)}</div><div style={{ fontSize: 12, color: 'var(--green)' }}>● Online</div></div>
                </div>
                <div className="chat-messages">
                  {msgs.map(m => (
                    <div key={m.id} style={{ display: 'flex', flexDirection: m.from === (currentUser?.id || 'guest') ? 'row-reverse' : 'row', gap: 8 }}>
                      <div className={`message-bubble ${m.from === (currentUser?.id || 'guest') ? 'message-mine' : 'message-theirs'}`}>
                        {m.text}
                        <div style={{ fontSize: 11, opacity: 0.6, marginTop: 4 }}>{m.time}</div>
                      </div>
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>
                <div className="chat-input-row">
                  <input className="form-input" style={{ flex: 1 }} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && sendMsg()} placeholder="Type a message…" />
                  <button className="btn btn-primary" onClick={sendMsg}>Send</button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
