function JobsPage({ currentUser, showToast }) {
  const [showPostJob, setShowPostJob] = useState(false);
  const [selected, setSelected] = useState(null);
  const [jobs, setJobs] = useState(STORE.jobs);
  const [category, setCategory] = useState('All');
  const [form, setForm] = useState({ title: '', category: 'Engineering', budget: '', type: 'Fixed Price', duration: '', description: '', skills: '' });
  const [showApply, setShowApply] = useState(false);
  const [proposal, setProposal] = useState('');
  const [proposalRate, setProposalRate] = useState('');

  const categories = ['All', 'Engineering', 'Design', 'Photography', 'Writing'];
  const filtered = jobs.filter(j => category === 'All' || j.category === category);

  function postJob() {
    if (!form.title || !form.budget || !form.description) { showToast('Please fill in all required fields', 'error'); return; }
    const job = {
      id: newId(), ...form,
      skills: form.skills.split(',').map(s => s.trim()).filter(Boolean),
      clientName: currentUser?.name || 'Anonymous',
      proposals: 0, posted: 'Just now', clientId: currentUser?.id || 'guest'
    };
    STORE.jobs = [job, ...STORE.jobs];
    setJobs([job, ...jobs]);
    setShowPostJob(false);
    setForm({ title: '', category: 'Engineering', budget: '', type: 'Fixed Price', duration: '', description: '', skills: '' });
    showToast('Job posted successfully!', 'success');
  }

  function applyJob() {
    if (!proposal || !proposalRate) { showToast('Please fill in all fields', 'error'); return; }
    selected.proposals = (selected.proposals || 0) + 1;
    setShowApply(false);
    setSelected(null);
    setProposal(''); setProposalRate('');
    showToast('Proposal submitted!', 'success');
  }

  return (
    <div className="fade-in">
      <div style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <h1 style={{ fontSize: 28, fontWeight: 600 }}>Job Listings</h1>
          <button className="btn btn-primary" onClick={() => setShowPostJob(true)}>+ Post a Job</button>
        </div>
      </div>

      <div className="section">
        <div style={{ display: 'flex', gap: 8, marginBottom: 24, flexWrap: 'wrap' }}>
          {categories.map(c => (
            <button key={c} className={`badge ${category === c ? 'badge-blue' : 'badge-gray'}`} style={{ cursor: 'pointer', padding: '6px 16px', fontSize: 13 }} onClick={() => setCategory(c)}>{c}</button>
          ))}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          {filtered.map(job => (
            <div key={job.id} className="card card-hover" style={{ cursor: 'pointer' }} onClick={() => setSelected(job)}>
              <div className="job-card">
                <div className="job-card-header">
                  <div>
                    <div className="job-card-title">{job.title}</div>
                    <div style={{ fontSize: 13, color: 'var(--text-secondary)', marginTop: 4 }}>{job.clientName} · Posted {job.posted}</div>
                  </div>
                  <div style={{ display: 'flex', gap: 8, flexShrink: 0 }}>
                    <span className="badge badge-blue">{job.category}</span>
                    <span className="badge badge-amber">{job.type}</span>
                  </div>
                </div>
                <p style={{ fontSize: 14, color: 'var(--text-secondary)', lineHeight: 1.6 }}>{job.description.slice(0,140)}…</p>
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 10 }}>
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                    {job.skills.map(s => <span className="chip" key={s}>{s}</span>)}
                  </div>
                  <div className="job-card-meta">
                    <span>💰 {job.budget}</span>
                    <span>⏱ {job.duration}</span>
                    <span>📋 {job.proposals} proposals</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Job Detail Modal */}
      {selected && (
        <Modal onClose={() => setSelected(null)} title="Job Details"
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setSelected(null)}>Close</button>
              <button className="btn btn-primary" onClick={() => { setShowApply(true); setSelected(null); }}>Submit Proposal</button>
            </>
          }>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
            <div>
              <h2 style={{ fontSize: 20, fontWeight: 600 }}>{selected.title}</h2>
              <p style={{ color: 'var(--text-secondary)', marginTop: 4 }}>{selected.clientName}</p>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--brand)' }}>{selected.budget}</div>
              <div style={{ fontSize: 13, color: 'var(--text-muted)', marginTop: 4 }}>{selected.type} · {selected.duration}</div>
            </div>
          </div>
          <div className="divider" />
          <p style={{ fontSize: 15, lineHeight: 1.7 }}>{selected.description}</p>
          <div>
            <h4 style={{ fontSize: 13, fontWeight: 600, textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 8 }}>Required Skills</h4>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {selected.skills.map(s => <span className="chip" key={s}>{s}</span>)}
            </div>
          </div>
          <div style={{ background: 'var(--surface-alt)', borderRadius: 'var(--radius)', padding: '14px 16px', display: 'flex', gap: 20 }}>
            <div><div style={{ fontSize: 18, fontWeight: 600 }}>{selected.proposals}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Proposals</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 600 }}>{selected.duration}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Timeline</div></div>
            <div><div style={{ fontSize: 18, fontWeight: 600 }}>{selected.posted}</div><div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Posted</div></div>
          </div>
        </Modal>
      )}

      {/* Apply Modal */}
      {showApply && (
        <Modal onClose={() => setShowApply(false)} title="Submit Proposal"
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setShowApply(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={applyJob}>Submit Proposal</button>
            </>
          }>
          <div className="form-group">
            <label className="form-label">Your proposed rate</label>
            <input className="form-input" value={proposalRate} onChange={e => setProposalRate(e.target.value)} placeholder="e.g. ₹1,200/hr or ₹75,000 fixed" />
          </div>
          <div className="form-group">
            <label className="form-label">Cover letter</label>
            <textarea className="form-input" rows={5} value={proposal} onChange={e => setProposal(e.target.value)} placeholder="Describe your relevant experience, approach, and why you're the best fit for this project…" />
          </div>
        </Modal>
      )}

      {/* Post Job Modal */}
      {showPostJob && (
        <Modal onClose={() => setShowPostJob(false)} title="Post a New Job"
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setShowPostJob(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={postJob}>Post Job</button>
            </>
          }>
          {[
            { key: 'title', label: 'Job Title *', placeholder: 'e.g. React Developer for E-commerce App' },
          ].map(f => (
            <div className="form-group" key={f.key}>
              <label className="form-label">{f.label}</label>
              <input className="form-input" value={form[f.key]} onChange={e => setForm(p => ({ ...p, [f.key]: e.target.value }))} placeholder={f.placeholder} />
            </div>
          ))}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div className="form-group">
              <label className="form-label">Category</label>
              <select className="form-input" value={form.category} onChange={e => setForm(p => ({ ...p, category: e.target.value }))}>
                {['Engineering','Design','Photography','Writing','Marketing','Other'].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
            <div className="form-group">
              <label className="form-label">Project Type</label>
              <select className="form-input" value={form.type} onChange={e => setForm(p => ({ ...p, type: e.target.value }))}>
                {['Fixed Price','Hourly','Retainer'].map(c => <option key={c}>{c}</option>)}
              </select>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <div className="form-group">
              <label className="form-label">Budget *</label>
              <input className="form-input" value={form.budget} onChange={e => setForm(p => ({ ...p, budget: e.target.value }))} placeholder="e.g. ₹50,000–₹80,000" />
            </div>
            <div className="form-group">
              <label className="form-label">Duration</label>
              <input className="form-input" value={form.duration} onChange={e => setForm(p => ({ ...p, duration: e.target.value }))} placeholder="e.g. 4 weeks" />
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Description *</label>
            <textarea className="form-input" rows={4} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))} placeholder="Describe the project in detail — scope, goals, deliverables, requirements…" />
          </div>
          <div className="form-group">
            <label className="form-label">Required Skills (comma-separated)</label>
            <input className="form-input" value={form.skills} onChange={e => setForm(p => ({ ...p, skills: e.target.value }))} placeholder="e.g. React, Node.js, MongoDB" />
          </div>
        </Modal>
      )}
    </div>
  );
}
