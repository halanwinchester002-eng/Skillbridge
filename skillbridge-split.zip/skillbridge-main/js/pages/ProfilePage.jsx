function ProfilePage({ currentUser, setCurrentUser, showToast }) {
  const [form, setForm] = useState(
    currentUser || { name: '', title: '', category: 'Engineering', location: '', rate: '', bio: '', skills: '', email: '', portfolio: '' }
  );
  const [tab, setTab] = useState('profile');
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewTarget, setReviewTarget] = useState('f1');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState('');

  async function saveProfile() {
    const updated = { ...form, id: currentUser?.id || newId(), skills: typeof form.skills === 'string' ? form.skills.split(',').map(s=>s.trim()).filter(Boolean) : form.skills, color: form.color || '#1a56db', avatar: form.name?.split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase() || 'ME', rating: form.rating || 4.8, reviews: form.reviews || 0, available: true };
    setCurrentUser(updated);
    const existing = STORE.freelancers.findIndex(f => f.id === updated.id);
    if (existing >= 0) STORE.freelancers[existing] = updated;
    else STORE.freelancers.push(updated);
    try { await FB.saveFreelancer(updated); } catch(e) {}
    showToast('Profile saved!', 'success');
  }

  function submitReview() {
    if (!reviewText) return;
    if (!STORE.reviews[reviewTarget]) STORE.reviews[reviewTarget] = [];
    STORE.reviews[reviewTarget].push({ id: newId(), clientName: currentUser?.name || 'You', rating: reviewRating, text: reviewText, date: 'Apr 2025' });
    setShowReviewForm(false); setReviewText(''); setReviewRating(5);
    showToast('Review submitted!', 'success');
  }

  return (
    <div className="fade-in">
      <div style={{ background: 'var(--surface)', borderBottom: '1px solid var(--border)', padding: '20px 24px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto' }}>
          <h1 style={{ fontSize: 24, fontWeight: 600 }}>My Account</h1>
        </div>
      </div>
      <div className="section">
        <div className="tabs" style={{ marginBottom: 28 }}>
          {['profile','portfolio','reviews'].map(t => (
            <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)} style={{ textTransform: 'capitalize' }}>{t}</button>
          ))}
        </div>

        {tab === 'profile' && (
          <div style={{ maxWidth: 640 }}>
            <div className="card" style={{ padding: 28 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 28 }}>
                <Avatar name={form.name || 'Me'} color={form.color || '#1a56db'} size="xl" />
                <div>
                  <h2 style={{ fontSize: 20, fontWeight: 600 }}>{form.name || 'Your Name'}</h2>
                  <p style={{ color: 'var(--text-secondary)' }}>{form.title || 'Your title'}</p>
                </div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                  {[['name','Full Name','e.g. Arjun Nair'],['title','Professional Title','e.g. Full-Stack Developer'],['email','Email','your@email.com'],['location','Location','e.g. Chennai, India'],['rate','Hourly Rate','e.g. ₹1,200/hr']].map(([k,l,p]) => (
                    <div className="form-group" key={k} style={k==='email'?{gridColumn:'1/-1'}:{}}>
                      <label className="form-label">{l}</label>
                      <input className="form-input" value={form[k]||''} onChange={e=>setForm(p=>({...p,[k]:e.target.value}))} placeholder={p} />
                    </div>
                  ))}
                </div>
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-input" value={form.category||'Engineering'} onChange={e=>setForm(p=>({...p,category:e.target.value}))}>
                    {['Engineering','Design','Photography','Writing','Marketing','Data & Analytics'].map(c=><option key={c}>{c}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Bio</label>
                  <textarea className="form-input" rows={4} value={form.bio||''} onChange={e=>setForm(p=>({...p,bio:e.target.value}))} placeholder="Describe your professional background, expertise, and what makes you unique…" />
                </div>
                <div className="form-group">
                  <label className="form-label">Skills (comma-separated)</label>
                  <input className="form-input" value={typeof form.skills === 'string' ? form.skills : (form.skills||[]).join(', ')} onChange={e=>setForm(p=>({...p,skills:e.target.value}))} placeholder="e.g. React, Node.js, TypeScript, PostgreSQL" />
                </div>
                <button className="btn btn-primary" style={{ alignSelf: 'flex-start', padding: '11px 28px' }} onClick={saveProfile}>Save Profile</button>
              </div>
            </div>
          </div>
        )}

        {tab === 'portfolio' && (
          <div style={{ maxWidth: 640 }}>
            <div className="card" style={{ padding: 28 }}>
              <h3 style={{ fontSize: 16, fontWeight: 600, marginBottom: 6 }}>Portfolio Items</h3>
              <p style={{ fontSize: 14, color: 'var(--text-secondary)', marginBottom: 20 }}>Showcase your best work to attract more clients.</p>
              <div className="form-group">
                <label className="form-label">Portfolio titles (comma-separated)</label>
                <input className="form-input" value={typeof form.portfolio === 'string' ? form.portfolio : (form.portfolio||[]).join(', ')} onChange={e=>setForm(p=>({...p,portfolio:e.target.value}))} placeholder="e.g. E-commerce Redesign, SaaS Dashboard, Mobile App" />
              </div>
              <button className="btn btn-primary" style={{ marginTop: 8 }} onClick={saveProfile}>Save Portfolio</button>
              {form.portfolio && (
                <div style={{ marginTop: 20, display: 'flex', flexWrap: 'wrap', gap: 10 }}>
                  {(typeof form.portfolio === 'string' ? form.portfolio.split(',') : form.portfolio||[]).filter(Boolean).map(p => (
                    <div key={p} style={{ background: 'var(--surface-hover)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '12px 18px', fontSize: 14 }}>📁 {p.trim()}</div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'reviews' && (
          <div style={{ maxWidth: 640 }}>
            <div className="card" style={{ padding: 28 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 }}>
                <h3 style={{ fontSize: 16, fontWeight: 600 }}>Leave a Review</h3>
                <button className="btn btn-primary btn-sm" onClick={() => setShowReviewForm(true)}>+ Write Review</button>
              </div>
              {Object.entries(STORE.reviews).flatMap(([fid, rs]) =>
                rs.filter(r => r.clientName === currentUser?.name).map(r => (
                  <div key={r.id} style={{ background: 'var(--surface-alt)', borderRadius: 'var(--radius)', padding: '14px 16px', marginBottom: 12 }}>
                    <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 6 }}>
                      <strong style={{ fontSize: 14 }}>{STORE.freelancers.find(f=>f.id===fid)?.name || fid}</strong>
                      <StarRating value={r.rating} readonly />
                    </div>
                    <p style={{ fontSize: 14, color: 'var(--text-secondary)' }}>{r.text}</p>
                  </div>
                ))
              )}
              {showReviewForm && (
                <Modal onClose={() => setShowReviewForm(false)} title="Write a Review"
                  footer={
                    <>
                      <button className="btn btn-secondary" onClick={() => setShowReviewForm(false)}>Cancel</button>
                      <button className="btn btn-primary" onClick={submitReview}>Submit Review</button>
                    </>
                  }>
                  <div className="form-group">
                    <label className="form-label">Freelancer</label>
                    <select className="form-input" value={reviewTarget} onChange={e => setReviewTarget(e.target.value)}>
                      {STORE.freelancers.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
                    </select>
                  </div>
                  <div className="form-group">
                    <label className="form-label">Rating</label>
                    <StarRating value={reviewRating} onChange={setReviewRating} />
                  </div>
                  <div className="form-group">
                    <label className="form-label">Your review</label>
                    <textarea className="form-input" rows={4} value={reviewText} onChange={e => setReviewText(e.target.value)} placeholder="Describe your experience working with this freelancer…" />
                  </div>
                </Modal>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
