// Demo data store (used for the sample freelancers/jobs shown in the UI)
let STORE = {
  users: {},
  freelancers: [
    { id: 'f1', name: 'Arjun Nair', title: 'Full-Stack Developer', category: 'Engineering', location: 'Chennai', rate: '₹1,200/hr', skills: ['React', 'Node.js', 'PostgreSQL'], bio: '6 years building scalable web apps. Love clean code and great UX.', rating: 4.9, reviews: 34, avatar: 'AN', color: '#1a56db', portfolio: ['E-commerce site', 'SaaS dashboard'], available: true },
    { id: 'f2', name: 'Priya Menon', title: 'UI/UX Designer', category: 'Design', location: 'Bangalore', rate: '₹900/hr', skills: ['Figma', 'User Research', 'Prototyping'], bio: 'Creating intuitive digital experiences for 5+ years. Specialize in SaaS products.', rating: 4.8, reviews: 21, avatar: 'PM', color: '#7c3aed', portfolio: ['Banking app redesign', 'Travel platform'], available: true },
    { id: 'f3', name: 'Karthik Raj', title: 'Commercial Photographer', category: 'Photography', location: 'Madurai', rate: '₹600/hr', skills: ['Product Photography', 'Retouching', 'Lightroom'], bio: 'Bringing brands to life through powerful imagery. 8 years in commercial photography.', rating: 5.0, reviews: 18, avatar: 'KR', color: '#059669', portfolio: ['Brand lookbook', 'Product catalog'], available: false },
    { id: 'f4', name: 'Sneha Patel', title: 'Content Writer', category: 'Writing', location: 'Mumbai', rate: '₹400/hr', skills: ['SEO Writing', 'Copywriting', 'Research'], bio: 'Crafting content that ranks and converts. Former journalist turned digital writer.', rating: 4.7, reviews: 52, avatar: 'SP', color: '#d97706', portfolio: ['Tech blog series', 'Product descriptions'], available: true },
    { id: 'f5', name: 'Rahul Verma', title: 'Data Scientist', category: 'Engineering', location: 'Hyderabad', rate: '₹1,500/hr', skills: ['Python', 'Machine Learning', 'TensorFlow'], bio: 'Turning raw data into actionable insights. PhD in CS, 4 years industry experience.', rating: 4.6, reviews: 15, avatar: 'RV', color: '#dc2626', portfolio: ['Churn prediction model', 'NLP pipeline'], available: true },
    { id: 'f6', name: 'Aisha Khan', title: 'Motion Designer', category: 'Design', location: 'Delhi', rate: '₹850/hr', skills: ['After Effects', 'Cinema 4D', 'Premiere Pro'], bio: 'Breathing life into brands with motion. 7 years in animation and video production.', rating: 4.9, reviews: 29, avatar: 'AK', color: '#0891b2', portfolio: ['Brand identity animation', 'Explainer videos'], available: true },
  ],
  jobs: [
    { id: 'j1', title: 'React Developer for E-commerce Rebuild', category: 'Engineering', budget: '₹80,000–₹1,20,000', type: 'Fixed Price', duration: '2 months', posted: '2 hours ago', description: 'We need an experienced React developer to rebuild our e-commerce frontend. Must have Redux and API integration experience.', skills: ['React', 'Redux', 'REST API'], clientName: 'TechRetail Pvt Ltd', proposals: 7, clientId: 'c1' },
    { id: 'j2', title: 'Brand Identity Design for Startup', category: 'Design', budget: '₹40,000–₹60,000', type: 'Fixed Price', duration: '3 weeks', posted: '5 hours ago', description: 'Early-stage fintech startup needs a complete brand identity — logo, color palette, typography, and brand guidelines.', skills: ['Branding', 'Figma', 'Illustration'], clientName: 'FinFlow Ventures', proposals: 12, clientId: 'c2' },
    { id: 'j3', title: 'Product Photography – Monthly Retainer', category: 'Photography', budget: '₹25,000/month', type: 'Retainer', duration: 'Ongoing', posted: '1 day ago', description: 'Growing D2C brand needs a reliable product photographer for monthly catalog shoots. 40-60 products per session.', skills: ['Product Photography', 'Editing', 'Lighting'], clientName: 'Organika Foods', proposals: 4, clientId: 'c3' },
    { id: 'j4', title: '10 Blog Posts – B2B SaaS', category: 'Writing', budget: '₹15,000–₹20,000', type: 'Fixed Price', duration: '3 weeks', posted: '3 hours ago', description: 'Looking for an experienced B2B writer to create 10 in-depth blog posts (2000+ words each) targeting CTO audience. Topics provided.', skills: ['SEO Writing', 'B2B Marketing', 'Research'], clientName: 'Clarix Software', proposals: 19, clientId: 'c4' },
    { id: 'j5', title: 'Python ML Model for Customer Churn', category: 'Engineering', budget: '₹60,000–₹90,000', type: 'Fixed Price', duration: '6 weeks', posted: '6 hours ago', description: 'We have 3 years of transactional data and need a churn prediction model with at least 85% accuracy, plus an explanation dashboard.', skills: ['Python', 'Scikit-learn', 'Data Visualization'], clientName: 'GrowthStack Inc', proposals: 6, clientId: 'c5' },
  ],
  reviews: {
    f1: [{ id: 'r1', clientName: 'Priya S', rating: 5, text: 'Arjun delivered exceptional work ahead of schedule. Very professional and communicative.', date: 'Dec 2024' }],
    f2: [{ id: 'r2', clientName: 'Vikram R', rating: 5, text: 'Priya completely transformed our product. Thoughtful UX decisions at every step.', date: 'Jan 2025' }],
  },
  messages: {},
};

let nextId = 100;
const newId = () => `id${nextId++}`;
